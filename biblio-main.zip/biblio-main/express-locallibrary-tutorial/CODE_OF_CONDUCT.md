# Code of conduct

This repository is governed by Mozilla's code of conduct and etiquette guidelines.
For more details, read [Mozilla's Community Participation Guidelines](https://www.mozilla.org/about/governance/policies/participation/).

## Reporting violations

For more information on how to report violations of the Community Participation Guidelines, read the [How to report](https://www.mozilla.org/about/governance/policies/participation/reporting/) page.
